package de.gajd.idod.interfaces;

public interface ConfirmationDialogCallback {
    void onDecision(boolean confirmed);
}