package de.gajd.idod.methods;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import de.gajd.idod.viewModels.KontaktViewModel;

public class NetzwerkUtils {
	
	private static KontaktViewModel viewModel;
	
	//	public static void setViewModel(ViewModelStoreOwner owner){
	//		viewModel = new ViewModelProvider(owner).get(SharedViewModel.class);
	//	}
	
	public static ConnectivityManager.NetworkCallback createNetworkCallback() {
		return new ConnectivityManager.NetworkCallback() {
			@Override
			public void onAvailable(Network network) {
				if(viewModel != null){
					//viewModel.setNetworkStatus(true);
				}
			}
			
			@Override
			public void onLost(Network network) {
				if(viewModel != null){
					//viewModel.setNetworkStatus(false);
				}
			}
		};
	}
	
	public static void registerNetworkCallback(Context context) {
		ConnectivityManager connectivityManager =
		(ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		
		NetworkRequest networkRequest = new NetworkRequest.Builder()
		.addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
		.build();
		
		connectivityManager.registerNetworkCallback(networkRequest, createNetworkCallback());
	}
}