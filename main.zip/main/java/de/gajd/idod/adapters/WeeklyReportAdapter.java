package de.gajd.idod.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import de.gajd.idod.R;
import de.gajd.idod.models.CheckInOut;

public class WeeklyReportAdapter extends ArrayAdapter<CheckInOut> {
	
	private Context context;
	private List<CheckInOut> dataList;
	//private WeeklyReportItemBinding binding;
	
	public WeeklyReportAdapter(@NonNull Context context, List<CheckInOut> dataList) {
		super(context, 0, dataList);
		this.context = context;
		this.dataList = dataList;
	}
	
	@NonNull
	@Override
	//public WeeklyReportItemBinding inflateBinding(ViewGroup parent) {
	//	LayoutInflater inflater = LayoutInflater.from(parent.getContext());
	//	return WeeklyReportItemBinding.inflate(inflater, parent, false);
	//}
	public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.weekly_report_item, parent, false);
		}
		
		CheckInOut data = dataList.get(position);
		
		TextView textViewDate = convertView.findViewById(R.id.textViewDate);
		TextView textViewAddress = convertView.findViewById(R.id.textViewAddress);
		TextView textViewDuration = convertView.findViewById(R.id.textViewDuration);
		
		// Setzen der Daten in die Views
		textViewDate.setText(formatDate(data.getCheckInTime()));
		textViewAddress.setText(data.getAddress());
		textViewDuration.setText(data.getDuration());
		
		return convertView;
	}
	
	private String formatDate(String dateTime) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
			Date date = sdf.parse(dateTime);
			return new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(date);
			} catch (Exception e) {
			e.printStackTrace();
			return dateTime;
		}
	}
}