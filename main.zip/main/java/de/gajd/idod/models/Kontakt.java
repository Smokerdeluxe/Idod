package de.gajd.idod.models;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.database.Exclude;
import de.gajd.idod.interfaces.Identifiable;
import de.gajd.idod.models.Kontakt;
import java.util.Objects;

public class Kontakt implements Identifiable<Kontakt>{
	private String key;
	private String name;
	private String nummer;
	private String email;
	private String funktion;
	
	// Leerer Konstruktor für Firebase
	public Kontakt() {}
	
	public Kontakt(@NonNull String name, @NonNull String nummer,
	@NonNull String email, @NonNull String funktion) {
	//	this.key = key;
		this.name = name;
		this.nummer = nummer;
		this.email = email;
		this.funktion = funktion;	
	}
	
	// Getter und Setter
	@Exclude
	public String getKey() { return key; }
	@Exclude
	public Kontakt setKey(String key) { this.key = key; return this;}
		
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	
	public String getNummer() { return nummer; }
	public void setNummer(String nummer) { this.nummer = nummer; }
		
	public String getEmail() { return email; }
	public void setEmail(String email) { this.email = email; }
		
	public String getFunktion() { return funktion; }
	public void setFunktion(String funktion) { this.funktion = funktion; }

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null || getClass() != obj.getClass()) return false;
		Kontakt that = (Kontakt) obj;
		return Objects.equals(key, that.key);
	}

	@Override
	public int hashCode() {
		return Objects.hash(key);
	}

	// toString() für Debugging
	@Override
	public String toString() {
		return "Kontakt{" +
		"key='" + key + '\'' +
		", name='" + name + '\'' +
		", nummer='" + nummer + '\'' +
		", email='" + email + '\'' +
		", funktion='" + funktion + '\'' +
		'}';
	}

	// Implementierung von Identifiable
	@Override
	public boolean isSameContent(Kontakt other) {
		if(other == null) return false;
		return Objects.equals(name, other.name) &&
		Objects.equals(nummer, other.nummer) &&
		Objects.equals(email, other.email) &&
		Objects.equals(funktion, other.funktion);
	}

	@Override
	public Object getChangePayload(Kontakt other) {
		return null; // Falls nötig, hier differenzierte Änderungen zurückgeben
	}
}