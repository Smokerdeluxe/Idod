package de.gajd.idod.utils;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import androidx.appcompat.app.AlertDialog;
import de.gajd.idod.databinding.DialogUserEditBinding;
import de.gajd.idod.interfaces.ConfirmationDialogCallback;
import de.gajd.idod.models.Kontakt;

public class Kontakte {
	
	private Kontakt newItem;
	
	public Kontakt editDialog(LayoutInflater inflater, Context context, Kontakt item, String key, ConfirmationDialogCallback callback) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		DialogUserEditBinding dialogBinding = DialogUserEditBinding.inflate(inflater);
		builder.setView(dialogBinding.getRoot());
		dialogBinding.etStatus.setVisibility(View.GONE);
		dialogBinding.etProfi.setVisibility(View.GONE);
		
		if(item != null) {
			dialogBinding.etName.setText(item.getName());
			dialogBinding.etPhone.setText(item.getNummer());
			dialogBinding.etEmail.setText(item.getEmail());
			dialogBinding.etFunktion.setText(item.getFunktion());

			builder.setTitle("Kontakt bearbeiten");
			} else {
			builder.setTitle("Kontakt erstellen");
		}
		builder.setPositiveButton("Speichern", (dialog, which) -> {
			newItem = new Kontakt(
				dialogBinding.etName.getText().toString().trim(), 
				dialogBinding.etPhone.getText().toString().trim(),
				dialogBinding.etEmail.getText().toString().trim(), 
				dialogBinding.etFunktion.getText().toString().trim()
			);
			callback.onDecision(true);
			dialog.dismiss();
			/*
			if(item != null){
				viewModel.save(key, newItem);
				Toast.makeText(requireContext(), "Kontakt aktualisiert", Toast.LENGTH_SHORT).show();
				}else{
				viewModel.add(newItem);
				Toast.makeText(requireContext(), "Kontakt hinugefügt", Toast.LENGTH_SHORT).show();
			}
			*/
		});
		
		builder.setNegativeButton("Abbrechen", (dialog, which) -> {
			callback.onDecision(false);
			dialog.dismiss();
		});
		AlertDialog dialog = builder.create();
		dialog.show();
		
		return newItem;
	}
}